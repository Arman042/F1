//
//  main.c
//  XML-Converter
//
//  Created by Arman on 30.03.25.
//

#include <stdlib.h>

int main(void)
{
    system("/Users/arman/Desktop/untitled folder 2/XML-Converter/XML-Converter/generate_f1_2025.py");
    return 0;
}

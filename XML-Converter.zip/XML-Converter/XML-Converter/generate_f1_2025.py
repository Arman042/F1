import xml.etree.ElementTree as ET
from xml.dom import minidom

# Teams data (full data including all teams and detailed stats)
teams_data = [
    {"name": "McLaren", "engine": "Mercedes-AMG M14", "constructor_points": 0, "drivers": [
        {"name": "Lando Norris", "car_number": 4, "nationality": "British", "car_model": "MCL39", "points": 0, "wins": 0, "podiums": 0, "pole_positions": 0, "fastest_laps": 0},
        {"name": "Oscar Piastri", "car_number": 81, "nationality": "Australian", "car_model": "MCL39", "points": 0, "wins": 0, "podiums": 0, "pole_positions": 0, "fastest_laps": 0}
    ]},
    {"name": "Ferrari", "engine": "Ferrari 066/10", "constructor_points": 0, "drivers": [
        {"name": "Charles Leclerc", "car_number": 16, "nationality": "Monegasque", "car_model": "SF-25", "points": 0, "wins": 0, "podiums": 0, "pole_positions": 0, "fastest_laps": 0},
        {"name": "Lewis Hamilton", "car_number": 44, "nationality": "British", "car_model": "SF-25", "points": 0, "wins": 0, "podiums": 0, "pole_positions": 0, "fastest_laps": 0}
    ]},
    {"name": "Red Bull", "engine": "Honda RBPTH001", "constructor_points": 0, "drivers": [
        {"name": "Max Verstappen", "car_number": 1, "nationality": "Dutch", "car_model": "RB21", "points": 0, "wins": 0, "podiums": 0, "pole_positions": 0, "fastest_laps": 0},
        {"name": "Yuki Tsunoda", "car_number": 22, "nationality": "Japanese", "car_model": "RB21", "points": 0, "wins": 0, "podiums": 0, "pole_positions": 0, "fastest_laps": 0}
    ]},
    {"name": "Mercedes", "engine": "Mercedes-AMG M14", "constructor_points": 0, "drivers": [
        {"name": "George Russell", "car_number": 63, "nationality": "British", "car_model": "W15", "points": 0, "wins": 0, "podiums": 0, "pole_positions": 0, "fastest_laps": 0},
        {"name": "Andrea Kimi Antonelli", "car_number": 40, "nationality": "Italian", "car_model": "W15", "points": 0, "wins": 0, "podiums": 0, "pole_positions": 0, "fastest_laps": 0}
    ]},
    {"name": "Aston Martin", "engine": "Mercedes-AMG M14", "constructor_points": 0, "drivers": [
        {"name": "Fernando Alonso", "car_number": 14, "nationality": "Spanish", "car_model": "AMR25", "points": 0, "wins": 0, "podiums": 0, "pole_positions": 0, "fastest_laps": 0},
        {"name": "Lance Stroll", "car_number": 18, "nationality": "Canadian", "car_model": "AMR25", "points": 0, "wins": 0, "podiums": 0, "pole_positions": 0, "fastest_laps": 0}
    ]},
    {"name": "Alpine", "engine": "Renault E-Tech RE23", "constructor_points": 0, "drivers": [
        {"name": "Pierre Gasly", "car_number": 10, "nationality": "French", "car_model": "A525", "points": 0, "wins": 0, "podiums": 0, "pole_positions": 0, "fastest_laps": 0},
        {"name": "Jack Doohan", "car_number": 45, "nationality": "Australian", "car_model": "A525", "points": 0, "wins": 0, "podiums": 0, "pole_positions": 0, "fastest_laps": 0}
    ]},
    {"name": "Haas", "engine": "Ferrari 066/10", "constructor_points": 0, "drivers": [
        {"name": "Esteban Ocon", "car_number": 31, "nationality": "French", "car_model": "VF-25", "points": 0, "wins": 0, "podiums": 0, "pole_positions": 0, "fastest_laps": 0},
        {"name": "Oliver Bearman", "car_number": 50, "nationality": "British", "car_model": "VF-25", "points": 0, "wins": 0, "podiums": 0, "pole_positions": 0, "fastest_laps": 0}
    ]},
    {"name": "Williams", "engine": "Mercedes-AMG M14", "constructor_points": 0, "drivers": [
        {"name": "Alex Albon", "car_number": 23, "nationality": "Thai", "car_model": "FW46", "points": 0, "wins": 0, "podiums": 0, "pole_positions": 0, "fastest_laps": 0},
        {"name": "Carlos Sainz", "car_number": 55, "nationality": "Spanish", "car_model": "FW46", "points": 0, "wins": 0, "podiums": 0, "pole_positions": 0, "fastest_laps": 0}
    ]},
    {"name": "Sauber", "engine": "Ferrari 066/10", "constructor_points": 0, "drivers": [
        {"name": "Nico Hülkenberg", "car_number": 27, "nationality": "German", "car_model": "C44", "points": 0, "wins": 0, "podiums": 0, "pole_positions": 0, "fastest_laps": 0},
        {"name": "Gabriel Bortoleto", "car_number": 42, "nationality": "Brazilian", "car_model": "C44", "points": 0, "wins": 0, "podiums": 0, "pole_positions": 0, "fastest_laps": 0}
    ]},
    {"name": "RB", "engine": "Honda RBPTH001", "constructor_points": 0, "drivers": [
        {"name": "Liam Lawson", "car_number": 40, "nationality": "New Zealander", "car_model": "VCARB 01", "points": 0, "wins": 0, "podiums": 0, "pole_positions": 0, "fastest_laps": 0},
        {"name": "Isack Hadjar", "car_number": 50, "nationality": "French", "car_model": "VCARB 01", "points": 0, "wins": 0, "podiums": 0, "pole_positions": 0, "fastest_laps": 0}
    ]}
]

# Full 2025 race calendar (24 races)
races_data = [
     {"date": "2025-03-16", "circuit": "Albert Park", "country": "Australia", "sprint": 0, "completed": 0, "weather": "Rainy", "laps": 58, "lap_length_km": 5.278, "event_type": "Grand Prix"},
    {"date": "2025-03-23", "circuit": "Shanghai International", "country": "China", "sprint": 1, "completed": 0, "weather": "Cloudy", "laps": 56, "lap_length_km": 5.451, "event_type": "Grand Prix, Sprint Week"},
    {"date": "2025-04-06", "circuit": "Suzuka", "country": "Japan", "sprint": 0, "completed": 0, "weather": "Clear", "laps": 53, "lap_length_km": 5.807, "event_type": "Grand Prix"},
    {"date": "2025-04-13", "circuit": "Bahrain International", "country": "Bahrain", "sprint": 0, "completed": 0, "weather": "Clear", "laps": 57, "lap_length_km": 5.412, "event_type": "Grand Prix"},
    {"date": "2025-04-20", "circuit": "Jeddah Corniche", "country": "Saudi Arabia", "sprint": 0, "completed": 0, "weather": "Clear", "laps": 50, "lap_length_km": 6.175, "event_type": "Grand Prix"},
    {"date": "2025-05-04", "circuit": "Miami", "country": "USA", "sprint": 1, "completed": 0, "weather": "Sunny", "laps": 57, "lap_length_km": 5.412, "event_type": "Sprint Week"},
    {"date": "2025-05-18", "circuit": "Imola", "country": "Italy", "sprint": 0, "completed": 0, "weather": "Cloudy", "laps": 63, "lap_length_km": 4.909, "event_type": "Grand Prix"},
    {"date": "2025-05-25", "circuit": "Monaco", "country": "Monaco", "sprint": 0, "completed": 0, "weather": "Sunny", "laps": 78, "lap_length_km": 3.337, "event_type": "Grand Prix"},
     {"date": "2025-06-01", "circuit": "Barcelona", "country": "Spain", "sprint": 0, "completed": 0, "weather": "Sunny", "laps": 66, "lap_length_km": 4.675, "event_type": "Grand Prix"},
    {"date": "2025-06-15", "circuit": "Montreal", "country": "Canada", "sprint": 1, "completed": 0, "weather": "Rainy", "laps": 70, "lap_length_km": 4.361, "event_type": "Sprint Week"},
    {"date": "2025-06-29", "circuit": "Red Bull Ring", "country": "Austria", "sprint": 1, "completed": 0, "weather": "Clear", "laps": 71, "lap_length_km": 4.318, "event_type": "Sprint Week"},
    {"date": "2025-07-06", "circuit": "Silverstone", "country": "UK", "sprint": 0, "completed": 0, "weather": "Cloudy", "laps": 52, "lap_length_km": 5.891, "event_type": "Grand Prix"},
    {"date": "2025-07-27", "circuit": "Spa-Francorchamps", "country": "Belgium", "sprint": 0, "completed": 0, "weather": "Rainy", "laps": 44, "lap_length_km": 7.004, "event_type": "Grand Prix"},
    {"date": "2025-08-03", "circuit": "Hungaroring", "country": "Hungary", "sprint": 0, "completed": 0, "weather": "Sunny", "laps": 70, "lap_length_km": 4.381, "event_type": "Grand Prix"},
    {"date": "2025-08-31", "circuit": "Zandvoort", "country": "Netherlands", "sprint": 0, "completed": 0, "weather": "Cloudy", "laps": 72, "lap_length_km": 4.259, "event_type": "Grand Prix"},
    {"date": "2025-09-07", "circuit": "Monza", "country": "Italy", "sprint": 0, "completed": 0, "weather": "Clear", "laps": 53, "lap_length_km": 5.793, "event_type": "Grand Prix"},
    {"date": "2025-09-21", "circuit": "Baku City", "country": "Azerbaijan", "sprint": 1, "completed": 0, "weather": "Sunny", "laps": 51, "lap_length_km": 6.003, "event_type": "Sprint Week"},
    {"date": "2025-10-05", "circuit": "Marina Bay", "country": "Singapore", "sprint": 0, "completed": 0, "weather": "Night", "laps": 61, "lap_length_km": 5.063, "event_type": "Grand Prix"},
    {"date": "2025-10-19", "circuit": "Circuit of the Americas", "country": "USA", "sprint": 1, "completed": 0, "weather": "Sunny", "laps": 56, "lap_length_km": 5.513, "event_type": "Sprint Week"},
    {"date": "2025-10-26", "circuit": "Mexico City", "country": "Mexico", "sprint": 0, "completed": 0, "weather": "Clear", "laps": 71, "lap_length_km": 4.304, "event_type": "Grand Prix"},
    {"date": "2025-11-09", "circuit": "Interlagos", "country": "Brazil", "sprint": 1, "completed": 0, "weather": "Rainy", "laps": 71, "lap_length_km": 4.309, "event_type": "Sprint Week"},
    {"date": "2025-11-23", "circuit": "Las Vegas", "country": "USA", "sprint": 0, "completed": 0, "weather": "Night", "laps": 50, "lap_length_km": 6.120, "event_type": "Grand Prix"},
    {"date": "2025-11-30", "circuit": "Losail", "country": "Qatar", "sprint": 1, "completed": 0, "weather": "Clear", "laps": 57, "lap_length_km": 5.380, "event_type": "Sprint Week"},
    {"date": "2025-12-07", "circuit": "Yas Marina", "country": "Abu Dhabi", "sprint": 0, "completed": 0, "weather": "Night", "laps": 58, "lap_length_km": 5.281, "event_type": "Grand Prix"}
]

# Adding data to XML
root = ET.Element("Data")

for team in teams_data:
    team_elem = ET.SubElement(root, "Team")
    ET.SubElement(team_elem, "Name").text = team["name"]
    ET.SubElement(team_elem, "Engine").text = team["engine"]
    ET.SubElement(team_elem, "ConstructorPoints").text = str(team["constructor_points"])
    for driver in team["drivers"]:
        driver_elem = ET.SubElement(team_elem, "Driver")
        ET.SubElement(driver_elem, "Name").text = driver["name"]
        ET.SubElement(driver_elem, "CarNumber").text = str(driver["car_number"])
        ET.SubElement(driver_elem, "Nationality").text = driver["nationality"]
        ET.SubElement(driver_elem, "CarModel").text = driver["car_model"]
        ET.SubElement(driver_elem, "Points").text = str(driver["points"])
        ET.SubElement(driver_elem, "Wins").text = str(driver["wins"])
        ET.SubElement(driver_elem, "Podiums").text = str(driver["podiums"])
        ET.SubElement(driver_elem, "PolePositions").text = str(driver["pole_positions"])
        ET.SubElement(driver_elem, "FastestLaps").text = str(driver["fastest_laps"])

for race in races_data:
    race_elem = ET.SubElement(root, "Race")
    ET.SubElement(race_elem, "Date").text = race["date"]
    ET.SubElement(race_elem, "Circuit").text = race["circuit"]
    ET.SubElement(race_elem, "Country").text = race["country"]
    ET.SubElement(race_elem, "Sprint").text = str(race["sprint"])
    ET.SubElement(race_elem, "Completed").text = str(race["completed"])
    ET.SubElement(race_elem, "Weather").text = race["weather"]
    ET.SubElement(race_elem, "Laps").text = str(race["laps"])
    ET.SubElement(race_elem, "LapLengthKm").text = str(race["lap_length_km"])

# Saving to XML file
xml_str = ET.tostring(root, encoding="unicode")
pretty_xml = minidom.parseString(xml_str).toprettyxml(indent="  ")
with open("f1_2025.xml", "w", encoding="utf-8") as f:
    f.write(pretty_xml)

print("Generated 'f1_2025.xml' with additional race and driver details.")

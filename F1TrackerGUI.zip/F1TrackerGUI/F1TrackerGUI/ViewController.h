//
//  ViewController.h
//  F1TrackerGUI
//
//  Created by Arman on 30.03.25.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController


@end


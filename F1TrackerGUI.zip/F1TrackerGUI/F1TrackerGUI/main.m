//
//  main.m
//  F1TrackerGUI
//
//  Created by Arman on 30.03.25.
//

#include <Cocoa/Cocoa.h>
#include "datastructure.h"

@interface AppDelegate : NSObject <NSApplicationDelegate, NSTableViewDataSource, NSTableViewDelegate>
@property (strong) NSWindow *window;
@property (strong) NSTabView *tabView;
@property (strong) NSTableView *driversTable;
@property (strong) NSTableView *teamsTable;
@property (strong) NSTableView *racesTable;
@property (strong) NSTextField *homeStatsLabel;
@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Load data
    load("f1_2025.xml");

    // Window setup
    self.window = [[NSWindow alloc] initWithContentRect:NSMakeRect(0, 0, 800, 600)
                                              styleMask:NSWindowStyleMaskTitled | NSWindowStyleMaskClosable | NSWindowStyleMaskResizable
                                                backing:NSBackingStoreBuffered
                                                  defer:NO];
    [self.window setTitle:@"F1 2025 Tracker"];
    [self.window center];

    // Tab view (bottom navigation)
    self.tabView = [[NSTabView alloc] initWithFrame:NSMakeRect(10, 10, 780, 580)];
    [self.tabView setTabViewType:NSBottomTabsBezelBorder];
    [self.window.contentView addSubview:self.tabView];

    // Home tab (overview with stats)
    NSTabViewItem *homeTab = [[NSTabViewItem alloc] initWithIdentifier:@"Home"];
    [homeTab setLabel:@"Home"];
    NSView *homeView = [[NSView alloc] initWithFrame:self.tabView.bounds];
    self.homeStatsLabel = [[NSTextField alloc] initWithFrame:NSMakeRect(10, 500, 760, 50)];
    [self.homeStatsLabel setEditable:NO];
    [self.homeStatsLabel setStringValue:@"Points: 0 | Races: 0 | Drivers: 0"];
    [self.homeStatsLabel setFont:[NSFont boldSystemFontOfSize:16]];
    [homeView addSubview:self.homeStatsLabel];
    [homeTab setView:homeView];
    [self.tabView addTabViewItem:homeTab];

    // Drivers tab (standings list)
    NSTabViewItem *driversTab = [[NSTabViewItem alloc] initWithIdentifier:@"Drivers"];
    [driversTab setLabel:@"Drivers"];
    NSScrollView *driversScroll = [[NSScrollView alloc] initWithFrame:self.tabView.bounds];
    self.driversTable = [[NSTableView alloc] initWithFrame:driversScroll.bounds];
    NSTableColumn *driverCol = [[NSTableColumn alloc] initWithIdentifier:@"Driver"];
    [driverCol setWidth:500];
    [driverCol.headerCell setStringValue:@"Driver"];
    NSTableColumn *pointsCol = [[NSTableColumn alloc] initWithIdentifier:@"Points"];
    [pointsCol setWidth:200];
    [pointsCol.headerCell setStringValue:@"Points"];
    [self.driversTable addTableColumn:driverCol];
    [self.driversTable addTableColumn:pointsCol];
    [self.driversTable setDataSource:self];
    [self.driversTable setDelegate:self];
    [driversScroll setDocumentView:self.driversTable];
    [driversTab setView:driversScroll];
    [self.tabView addTabViewItem:driversTab];

    // Teams tab (standings list)
    NSTabViewItem *teamsTab = [[NSTabViewItem alloc] initWithIdentifier:@"Teams"];
    [teamsTab setLabel:@"Teams"];
    NSScrollView *teamsScroll = [[NSScrollView alloc] initWithFrame:self.tabView.bounds];
    self.teamsTable = [[NSTableView alloc] initWithFrame:teamsScroll.bounds];
    NSTableColumn *teamCol = [[NSTableColumn alloc] initWithIdentifier:@"Team"];
    [teamCol setWidth:500];
    [teamCol.headerCell setStringValue:@"Team"];
    NSTableColumn *teamPointsCol = [[NSTableColumn alloc] initWithIdentifier:@"Points"];
    [teamPointsCol setWidth:200];
    [teamPointsCol.headerCell setStringValue:@"Points"];
    [self.teamsTable addTableColumn:teamCol];
    [self.teamsTable addTableColumn:teamPointsCol];
    [self.teamsTable setDataSource:self];
    [self.teamsTable setDelegate:self];
    [teamsScroll setDocumentView:self.teamsTable];
    [teamsTab setView:teamsScroll];
    [self.tabView addTabViewItem:teamsTab];

    // Races tab (list without update button)
    NSTabViewItem *racesTab = [[NSTabViewItem alloc] initWithIdentifier:@"Races"];
    [racesTab setLabel:@"Races"];
    NSScrollView *racesScroll = [[NSScrollView alloc] initWithFrame:self.tabView.bounds];
    self.racesTable = [[NSTableView alloc] initWithFrame:racesScroll.bounds];
    NSTableColumn *dateCol = [[NSTableColumn alloc] initWithIdentifier:@"Date"];
    [dateCol setWidth:150];
    [dateCol.headerCell setStringValue:@"Date"];
    NSTableColumn *circuitCol = [[NSTableColumn alloc] initWithIdentifier:@"Circuit"];
    [circuitCol setWidth:550];
    [circuitCol.headerCell setStringValue:@"Circuit"];
    [self.racesTable addTableColumn:dateCol];
    [self.racesTable addTableColumn:circuitCol];
    [self.racesTable setDataSource:self];
    [self.racesTable setDelegate:self];
    [racesScroll setDocumentView:self.racesTable];
    [racesTab setView:racesScroll];
    [self.tabView addTabViewItem:racesTab];

    // Settings tab (placeholder)
    NSTabViewItem *settingsTab = [[NSTabViewItem alloc] initWithIdentifier:@"Settings"];
    [settingsTab setLabel:@"Settings"];
    NSView *settingsView = [[NSView alloc] initWithFrame:self.tabView.bounds];
    NSTextField *settingsLabel = [[NSTextField alloc] initWithFrame:NSMakeRect(10, 500, 760, 50)];
    [settingsLabel setEditable:NO];
    [settingsLabel setStringValue:@"Settings (To Be Implemented)"];
    [settingsView addSubview:settingsLabel];
    [settingsTab setView:settingsView];
    [self.tabView addTabViewItem:settingsTab];

    // Initial stats update
    [self updateHomeStats];
    [self.window makeKeyAndOrderFront:nil];
}

- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView {
    if (tableView == self.driversTable) {
        int totalDrivers = 0;
        for (int i = 0; i < team_count; i++) {
            totalDrivers += teams[i].driver_count;
        }
        return totalDrivers;
    } else if (tableView == self.teamsTable) {
        return team_count;
    } else if (tableView == self.racesTable) {
        return race_count;
    }
    return 0;
}

- (id)tableView:(NSTableView *)tableView objectValueForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row {
    if (tableView == self.driversTable) {
        int driverCount = 0;
        for (int i = 0; i < team_count; i++) {
            for (int j = 0; j < teams[i].driver_count; j++) {
                if (driverCount == row) {
                    if ([tableColumn.identifier isEqualToString:@"Driver"]) {
                        return @(teams[i].drivers[j].name);
                    } else if ([tableColumn.identifier isEqualToString:@"Points"]) {
                        return @(teams[i].drivers[j].total_points);
                    }
                }
                driverCount++;
            }
        }
    } else if (tableView == self.teamsTable) {
        if ([tableColumn.identifier isEqualToString:@"Team"]) {
            return @(teams[row].name);
        } else if ([tableColumn.identifier isEqualToString:@"Points"]) {
            return @(teams[row].total_points);
        }
    } else if (tableView == self.racesTable) {
        if ([tableColumn.identifier isEqualToString:@"Date"]) {
            return @(races[row].date);
        } else if ([tableColumn.identifier isEqualToString:@"Circuit"]) {
            return @(races[row].circuit);
        }
    }
    return nil;
}

- (void)updateHomeStats {
    int totalPoints = 0;
    int completedRaces = 0;
    int totalDrivers = 0;
    for (int i = 0; i < team_count; i++) {
        totalPoints += teams[i].total_points;
        totalDrivers += teams[i].driver_count;
    }
    for (int r = 0; r < race_count; r++) {
        if (races[r].completed) completedRaces++;
    }
    [self.homeStatsLabel setStringValue:[NSString stringWithFormat:@"Points: %d | Races: %d | Drivers: %d", totalPoints, completedRaces, totalDrivers]];
}

@end

int main(int argc, const char *argv[]) {
    @autoreleasepool {
        NSApplication *app = [NSApplication sharedApplication];
        AppDelegate *delegate = [[AppDelegate alloc] init];
        [app setDelegate:delegate];
        [app run];
    }
    return 0;
}

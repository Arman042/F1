//
//  update_f1.c
//  Formula1
//
//  Created by Arman on 26.03.25.
//

#include <stdio.h>
#include <string.h>
#include "datastructure.h"
#include "tool.h"

void save(const char* filename) {
    FILE* file = fopen(filename, "w");
    if (!file) {
        printf("Error: Could not open %s for writing.\n", filename);
        return;
    }

    fprintf(file, "<Formula1>\n");
    for (int i = 0; i < team_count; i++) {
        fprintf(file, "\t<Team>\n");
        fprintf(file, "\t\t<Name>%s</Name>\n", teams[i].name);
        for (int j = 0; j < teams[i].driver_count; j++) {
            fprintf(file, "\t\t<Driver>\n");
            fprintf(file, "\t\t\t<Name>%s</Name>\n", teams[i].drivers[j].name);
            fprintf(file, "\t\t\t<CarNumber>%d</CarNumber>\n", teams[i].drivers[j].car_number);
            fprintf(file, "\t\t\t<Nationality>%s</Nationality>\n", teams[i].drivers[j].nationality);
            fprintf(file, "\t\t\t<TotalPoints>%d</TotalPoints>\n", teams[i].drivers[j].total_points);
            fprintf(file, "\t\t\t<CarModel>%s</CarModel>\n", teams[i].drivers[j].car_model);
            fprintf(file, "\t\t\t<Bio>%s</Bio>\n", teams[i].drivers[j].bio);
            fprintf(file, "\t\t</Driver>\n");
        }
        fprintf(file, "\t\t<TotalPoints>%d</TotalPoints>\n", teams[i].total_points);
        fprintf(file, "\t</Team>\n");
    }

    for (int i = 0; i < race_count; i++) {
        fprintf(file, "\t<Race>\n");
        fprintf(file, "\t\t<Date>%s</Date>\n", races[i].date);
        fprintf(file, "\t\t<Circuit>%s</Circuit>\n", races[i].circuit);
        fprintf(file, "\t\t<Country>%s</Country>\n", races[i].country);
        fprintf(file, "\t\t<Sprint>%d</Sprint>\n", races[i].sprint);
        fprintf(file, "\t\t<Completed>%d</Completed>\n", races[i].completed);
        fprintf(file, "\t\t<DriverPoints>");
        for (int j = 0; j < MAX_TEAMS * MAX_DRIVERS; j++) {
            fprintf(file, "%d", races[i].finishing_positions[j]);
            if (j < MAX_TEAMS * MAX_DRIVERS - 1) fprintf(file, ",");
        }
        fprintf(file, "</DriverPoints>\n");
        fprintf(file, "\t\t<MapPath>%s</MapPath>\n", races[i].map_path);
        fprintf(file, "\t</Race>\n");
    }

    fprintf(file, "</Formula1>\n");
    fclose(file);
    printf("Data saved to %s\n", filename);
}

void update_race_results() {
    printf("Enter race number (1-%d): ", race_count);
    int race_num;
    scanf("%d", &race_num);
    clear_input_buffer();
    if (race_num < 1 || race_num > race_count) {
        printf("Invalid race number.\n");
        return;
    }
    struct Race* race = &races[race_num - 1];
    if (race->completed) {
        printf("%s is already completed. Overwrite? (y/n): ", race->circuit);
        char choice[2];
        get_string(choice, 2);
        if (choice[0] != 'y' && choice[0] != 'Y') return;
    }
    printf("Enter finishing positions for %s (20 comma-separated values, e.g., 1,2,3,...):\n", race->circuit);
    char positions[256];
    get_string(positions, 256);
    parse_race_points(race, positions, NULL);
    race->completed = 1;
    calculate_race_points(race);

    // Reset and recalculate totals
    for (int i = 0; i < team_count; i++) {
        teams[i].total_points = 0;
        for (int j = 0; j < teams[i].driver_count; j++) {
            teams[i].drivers[j].total_points = 0;
        }
    }
    for (int r = 0; r < race_count; r++) {
        if (races[r].completed) {
            calculate_race_points(&races[r]);
            for (int i = 0; i < team_count; i++) {
                teams[i].total_points += races[r].constructor_points[i];
                for (int j = 0; j < teams[i].driver_count; j++) {
                    int driver_idx = i * MAX_DRIVERS + j;
                    teams[i].drivers[j].total_points += races[r].driver_points[driver_idx];
                    printf("Driver %d (Team %d): %s, Points %d\n", driver_idx, i, teams[i].drivers[j].name, teams[i].drivers[j].total_points);
                }
                printf("Team %d: %s, Points %d\n", i, teams[i].name, teams[i].total_points);
            }
        }
    }

    // Save changes
    save("f1_2025.xml");
    printf("Results updated for %s.\n", race->circuit);
}

int main(int argc, const char *argv[]) {
    load("f1_2025.xml");
    printf("Loaded %d teams and %d races\n", team_count, race_count);

    char choice;
    do {
        printf("\n--- F1 2025 Update Tool ---\n");
        printf("1. Update Race Results\n");
        printf("2. Exit\n");
        printf("Enter your choice (1-2): ");
        scanf(" %c", &choice);
        clear_input_buffer();

        switch (choice) {
            case '1':
                update_race_results();
                break;
            case '2':
                printf("Exiting F1 2025 Update Tool.\n");
                break;
            default:
                printf("Invalid choice. Please enter 1 or 2.\n");
        }
    } while (choice != '2');

    return 0;
}

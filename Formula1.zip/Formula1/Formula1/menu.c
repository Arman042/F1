//
//  menu.c
//  Formula1
//
//  Created by Arman on 18.03.25.
//

#include <stdio.h>
#include "datastructure.h"
#include "tool.h"
#include "teams.h"
#include "list.h"
#include "sort.h"
#include "datetime.h"
#include "menu.h"

void update_race_results(void) {
    printf("Enter race number (1-%d): ", race_count);
    int race_num;
    scanf("%d", &race_num);
    clear_input_buffer();
    if (race_num < 1 || race_num > race_count) {
        printf("Invalid race number.\n");
        return;
    }
    struct Race* race = &races[race_num - 1];
    if (race->completed) {
        printf("%s is already completed. Overwrite? (y/n): ", race->circuit);
        char choice[2];
        get_string(choice, 2);
        if (choice[0] != 'y' && choice[0] != 'Y') return;
    }
    printf("Enter finishing positions for %s (20 comma-separated values, e.g., 1,2,3,...):\n", race->circuit);
    char positions[256];
    get_string(positions, 256);
    parse_race_points(race, positions, NULL);
    if (!race->sprint) {
        printf("Enter driver index for fastest lap (0-19, or -1 for none):\n");
        scanf("%d", &race->fastest_lap_driver);
        clear_input_buffer();
    }
    race->completed = 1;
    calculate_race_points(race);
    for (int i = 0; i < team_count; i++) {
        teams[i].total_points += race->constructor_points[i];
        for (int j = 0; j < teams[i].driver_count; j++) {
            int driver_idx = i * MAX_DRIVERS + j;
            teams[i].drivers[j].total_points += race->driver_points[driver_idx];
        }
    }
    printf("Results updated for %s.\n", race->circuit);
}

void display_menu(void) {
    int choice;
    do {
        printf("\n--- Formula 1 2025 Tracker Menu ---\n");
        printf("1. View Teams and Drivers\n");
        printf("2. View Race Calendar\n");
        printf("3. View Championships\n");
        printf("4. Update Race Results\n");
        printf("5. Exit\n");
        printf("Enter your choice (1-5): ");
        scanf("%d", &choice);
        clear_input_buffer();

        switch (choice) {
            case 1: display_teams(); break;
            case 2: display_calendar(); break;
            case 3: display_championships(); break;
            case 4: update_race_results(); break;
            case 5: printf("Exiting Formula 1 2025 Tracker. Goodbye!\n"); break;
            default: printf("Invalid choice. Please enter 1-5.\n");
        }
    } while (choice != 5);
}

//
//  teams.h
//  Formula1
//
//  Created by Arman on 18.03.25.
//

#ifndef TEAMS_H
#define TEAMS_H

void display_teams(void);

#endif

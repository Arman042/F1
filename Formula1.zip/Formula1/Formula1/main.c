//
//  main.c
//  Formula1
//
//  Created by Arman on 18.03.25.
//

#include <stdio.h>
#include "datastructure.h"
#include "menu.h"

int main(void)
{
    printf("Welcome to the Formula 1 2025 Tracker!\n");
    load("/Users/arman/Desktop/untitled folder 2/Formula1/Formula1/f1_2025.xml"); // Load data at startup
    display_menu();      // Run the menu loop
    return 0;
}

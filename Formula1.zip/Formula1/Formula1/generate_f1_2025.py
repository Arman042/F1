import xml.etree.ElementTree as ET
from xml.dom import minidom

# Teams data (unchanged)
teams_data = [
    {"name": "Red Bull Racing", "drivers": [
        {"name": "Max Verstappen", "car_number": 1, "nationality": "Dutch", "car_model": "RB21"},
        {"name": "Liam Lawson", "car_number": 30, "nationality": "New Zealand", "car_model": "RB21"}
    ]},
    {"name": "McLaren", "drivers": [
        {"name": "Lando Norris", "car_number": 4, "nationality": "British", "car_model": "MCL39"},
        {"name": "Oscar Piastri", "car_number": 81, "nationality": "Australian", "car_model": "MCL39"}
    ]},
    {"name": "Ferrari", "drivers": [
        {"name": "Charles Leclerc", "car_number": 16, "nationality": "Monegasque", "car_model": "SF-25"},
        {"name": "Lewis Hamilton", "car_number": 44, "nationality": "British", "car_model": "SF-25"}
    ]},
    {"name": "Mercedes", "drivers": [
        {"name": "George Russell", "car_number": 63, "nationality": "British", "car_model": "W16"},
        {"name": "Kimi Antonelli", "car_number": 12, "nationality": "Italian", "car_model": "W16"}
    ]},
    {"name": "Aston Martin", "drivers": [
        {"name": "Fernando Alonso", "car_number": 14, "nationality": "Spanish", "car_model": "AMR25"},
        {"name": "Lance Stroll", "car_number": 18, "nationality": "Canadian", "car_model": "AMR25"}
    ]},
    {"name": "Alpine", "drivers": [
        {"name": "Pierre Gasly", "car_number": 10, "nationality": "French", "car_model": "A525"},
        {"name": "Jack Doohan", "car_number": 61, "nationality": "Australian", "car_model": "A525"}
    ]},
    {"name": "Williams", "drivers": [
        {"name": "Alexander Albon", "car_number": 23, "nationality": "Thai", "car_model": "FW47"},
        {"name": "Carlos Sainz", "car_number": 55, "nationality": "Spanish", "car_model": "FW47"}
    ]},
    {"name": "Racing Bulls", "drivers": [
        {"name": "Yuki Tsunoda", "car_number": 22, "nationality": "Japanese", "car_model": "RB02"},
        {"name": "Isack Hadjar", "car_number": 20, "nationality": "French", "car_model": "RB02"}
    ]},
    {"name": "Sauber", "drivers": [
        {"name": "Nico Hulkenberg", "car_number": 27, "nationality": "German", "car_model": "C45"},
        {"name": "Gabriel Bortoletto", "car_number": 5, "nationality": "Brasilian", "car_model": "C45"}
    ]},
    {"name": "Haas", "drivers": [
        {"name": "Oliver Bearman", "car_number": 87, "nationality": "British", "car_model": "VF-25"},
        {"name": "Esteban Ocon", "car_number": 31, "nationality": "French", "car_model": "VF-25"}
    ]},
]

# Full 2025 race calendar (24 races)
races_data = [
    {"date": "2025-03-16", "circuit": "Albert Park", "country": "Australia", "sprint": 0, "completed": 1,
     "finishing_positions": "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20", "fastest_lap_driver": "0"},
    {"date": "2025-03-23", "circuit": "Shanghai International", "country": "China", "sprint": 1, "completed": 0},
    {"date": "2025-04-06", "circuit": "Suzuka", "country": "Japan", "sprint": 0, "completed": 0},
    {"date": "2025-04-13", "circuit": "Bahrain International", "country": "Bahrain", "sprint": 0, "completed": 0},
    {"date": "2025-04-20", "circuit": "Jeddah Corniche", "country": "Saudi Arabia", "sprint": 0, "completed": 0},
    {"date": "2025-05-04", "circuit": "Miami", "country": "USA", "sprint": 1, "completed": 0},
    {"date": "2025-05-18", "circuit": "Imola", "country": "Italy", "sprint": 0, "completed": 0},
    {"date": "2025-05-25", "circuit": "Monaco", "country": "Monaco", "sprint": 0, "completed": 0},
    {"date": "2025-06-01", "circuit": "Barcelona", "country": "Spain", "sprint": 0, "completed": 0},
    {"date": "2025-06-15", "circuit": "Montreal", "country": "Canada", "sprint": 0, "completed": 0},
    {"date": "2025-06-29", "circuit": "Red Bull Ring", "country": "Austria", "sprint": 1, "completed": 0},
    {"date": "2025-07-06", "circuit": "Silverstone", "country": "UK", "sprint": 0, "completed": 0},
    {"date": "2025-07-27", "circuit": "Spa-Francorchamps", "country": "Belgium", "sprint": 0, "completed": 0},
    {"date": "2025-08-03", "circuit": "Hungaroring", "country": "Hungary", "sprint": 0, "completed": 0},
    {"date": "2025-08-31", "circuit": "Zandvoort", "country": "Netherlands", "sprint": 0, "completed": 0},
    {"date": "2025-09-07", "circuit": "Monza", "country": "Italy", "sprint": 0, "completed": 0},
    {"date": "2025-09-21", "circuit": "Baku City", "country": "Azerbaijan", "sprint": 1, "completed": 0},
    {"date": "2025-10-05", "circuit": "Marina Bay", "country": "Singapore", "sprint": 0, "completed": 0},
    {"date": "2025-10-19", "circuit": "Circuit of the Americas", "country": "USA", "sprint": 1, "completed": 0},
    {"date": "2025-10-26", "circuit": "Mexico City", "country": "Mexico", "sprint": 0, "completed": 0},
    {"date": "2025-11-09", "circuit": "Interlagos", "country": "Brazil", "sprint": 1, "completed": 0},
    {"date": "2025-11-23", "circuit": "Las Vegas", "country": "USA", "sprint": 0, "completed": 0},
    {"date": "2025-11-30", "circuit": "Losail", "country": "Qatar", "sprint": 1, "completed": 0},
    {"date": "2025-12-07", "circuit": "Yas Marina", "country": "Abu Dhabi", "sprint": 0, "completed": 0},
]

# Build XML structure
root = ET.Element("Data")

for team in teams_data:
    team_elem = ET.SubElement(root, "Team")
    ET.SubElement(team_elem, "Name").text = team["name"]
    for driver in team["drivers"]:
        driver_elem = ET.SubElement(team_elem, "Driver")
        ET.SubElement(driver_elem, "Name").text = driver["name"]
        ET.SubElement(driver_elem, "CarNumber").text = str(driver["car_number"])
        ET.SubElement(driver_elem, "Nationality").text = driver["nationality"]
        ET.SubElement(driver_elem, "CarModel").text = driver["car_model"]

for race in races_data:
    race_elem = ET.SubElement(root, "Race")
    ET.SubElement(race_elem, "Date").text = race["date"]
    ET.SubElement(race_elem, "Circuit").text = race["circuit"]
    ET.SubElement(race_elem, "Country").text = race["country"]
    ET.SubElement(race_elem, "Sprint").text = str(race["sprint"])
    ET.SubElement(race_elem, "Completed").text = str(race["completed"])
    if "finishing_positions" in race:
        ET.SubElement(race_elem, "DriverPoints").text = race["finishing_positions"]
    if "fastest_lap_driver" in race:
        ET.SubElement(race_elem, "FastestLapDriver").text = race["fastest_lap_driver"]

# Save to file
xml_str = ET.tostring(root, encoding="unicode")
pretty_xml = minidom.parseString(xml_str).toprettyxml(indent="  ")
with open("f1_2025.xml", "w", encoding="utf-8") as f:
    f.write(pretty_xml)

print("Generated 'f1_2025.xml' with 10 teams and 24 races.")

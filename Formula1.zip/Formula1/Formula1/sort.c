//
//  sort.c
//  Formula1
//
//  Created by Arman on 18.03.25.
//

#include <stdio.h>
#include "datastructure.h"
#include "sort.h"

void sort_drivers_by_points(void) {
    struct DriverEntry {
        char* name;
        int points;
    };
    struct DriverEntry entries[MAX_TEAMS * MAX_DRIVERS];
    int total_drivers = 0;
    for (int i = 0; i < team_count; i++) {
        for (int j = 0; j < teams[i].driver_count; j++) {
            entries[total_drivers].name = teams[i].drivers[j].name;
            entries[total_drivers].points = teams[i].drivers[j].total_points;
            total_drivers++;
        }
    }
    for (int i = 0; i < total_drivers - 1; i++) {
        for (int j = 0; j < total_drivers - i - 1; j++) {
            if (entries[j].points < entries[j + 1].points) {
                struct DriverEntry temp = entries[j];
                entries[j] = entries[j + 1];
                entries[j + 1] = temp;
            }
        }
    }
    printf("\n--- Sorted Drivers' Championship ---\n");
    for (int i = 0; i < total_drivers; i++) {
        printf("%d. %s: %d points\n", i + 1, entries[i].name, entries[i].points);
    }
}

// Placeholder for sorting teams by points
void sort_teams_by_points(void) {
    printf("Sorting teams by points - feature to be implemented!\n");
    
    
}

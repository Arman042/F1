//
//  tools.h
//  Formula1
//
//  Created by Arman on 18.03.25.
//

#ifndef TOOL_H
#define TOOL_H

void get_string(char* buffer, int size);
void clear_input_buffer(void);

#endif

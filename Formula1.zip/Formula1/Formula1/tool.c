//
//  tools.c
//  Formula1
//
//  Created by Arman on 18.03.25.
//

#include <stdio.h>
#include <string.h>
#include "tool.h"

void get_string(char* buffer, int size) {
    if (fgets(buffer, size, stdin)) {
        buffer[strcspn(buffer, "\n")] = '\0';
    }
}

void clear_input_buffer(void) {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

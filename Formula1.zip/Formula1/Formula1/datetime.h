//
//  datetime.h
//  Formula1
//
//  Created by Arman on 18.03.25.
//

#ifndef DATETIME_H
#define DATETIME_H

int compare_dates(const char* date1, const char* date2);
int is_race_upcoming(const char* race_date);

#endif

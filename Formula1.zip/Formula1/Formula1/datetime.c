//
//  datetime.c
//  Formula1
//
//  Created by Arman on 18.03.25.
//

#include <stdio.h>
#include <string.h>
#include "datetime.h"

// Compare two dates (YYYY-MM-DD), returns -1 if date1 < date2, 0 if equal, 1 if date1 > date2
int compare_dates(const char* date1, const char* date2) {
    return strcmp(date1, date2); // Simple string comparison for now
}

// Check if a race is upcoming based on current date (March 18, 2025)
int is_race_upcoming(const char* race_date) {
    const char* current_date = "2025-03-18"; // Hardcoded for now
    return compare_dates(race_date, current_date) > 0;
}


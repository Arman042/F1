//
//  teams.c
//  Formula1
//
//  Created by Arman on 18.03.25.
//

#include <stdio.h>
#include "datastructure.h"
#include "teams.h"

void display_teams(void) {
    printf("\n--- Formula 1 2025 Teams and Drivers ---\n");
    for (int i = 0; i < team_count; i++) {
        printf("Team: %s\n", teams[i].name);
        for (int j = 0; j < teams[i].driver_count; j++) {
            printf("  Driver: %s, Car #%d, Nationality: %s, Car: %s\n",
                   teams[i].drivers[j].name, teams[i].drivers[j].car_number,
                   teams[i].drivers[j].nationality, teams[i].drivers[j].car_model);
        }
    }
}

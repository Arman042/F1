//
//  sort.h
//  Formula1
//
//  Created by Arman on 18.03.25.
//

#ifndef SORT_H
#define SORT_H

void sort_drivers_by_points(void);
void sort_teams_by_points(void);

#endif

#include <stdio.h>
#include <string.h>
#include "datastructure.h"
#include <libxml/parser.h>
#include <libxml/tree.h>

struct Team teams[MAX_TEAMS];
int team_count = 0;
struct Race races[MAX_RACES];
int race_count = 0;

void load(const char* filename) {
    xmlDoc* doc = xmlReadFile(filename, NULL, 0);
    if (!doc) {
        printf("Error: Could not parse %s\n", filename);
        return;
    }

    xmlNode* root = xmlDocGetRootElement(doc);
    for (xmlNode* node = root->children; node; node = node->next) {
        if (node->type != XML_ELEMENT_NODE) continue;

        if (strcmp((char*)node->name, "Team") == 0) {
            if (team_count >= MAX_TEAMS) continue;
            struct Team* team = &teams[team_count++];
            team->driver_count = 0;
            team->total_points = 0;

            for (xmlNode* child = node->children; child; child = child->next) {
                if (child->type != XML_ELEMENT_NODE) continue;

                if (strcmp((char*)child->name, "Name") == 0) {
                    xmlChar* name = xmlNodeGetContent(child);
                    strncpy(team->name, (char*)name, sizeof(team->name) - 1);
                    team->name[sizeof(team->name) - 1] = '\0';
                    xmlFree(name);
                } else if (strcmp((char*)child->name, "Driver") == 0) {
                    if (team->driver_count >= MAX_DRIVERS) continue;
                    struct Driver* driver = &team->drivers[team->driver_count++];

                    for (xmlNode* driver_child = child->children; driver_child; driver_child = driver_child->next) {
                        if (driver_child->type != XML_ELEMENT_NODE) continue;

                        xmlChar* content = xmlNodeGetContent(driver_child);
                        if (strcmp((char*)driver_child->name, "Name") == 0) {
                            strncpy(driver->name, (char*)content, sizeof(driver->name) - 1);
                        } else if (strcmp((char*)driver_child->name, "CarNumber") == 0) {
                            driver->car_number = atoi((char*)content);
                        } else if (strcmp((char*)driver_child->name, "Nationality") == 0) {
                            strncpy(driver->nationality, (char*)content, sizeof(driver->nationality) - 1);
                        } else if (strcmp((char*)driver_child->name, "TotalPoints") == 0) {
                            driver->total_points = atoi((char*)content);
                        } else if (strcmp((char*)driver_child->name, "CarModel") == 0) {
                            strncpy(driver->car_model, (char*)content, sizeof(driver->car_model) - 1);
                        } else if (strcmp((char*)driver_child->name, "Bio") == 0) {
                            strncpy(driver->bio, (char*)content, sizeof(driver->bio) - 1);
                        }
                        xmlFree(content);
                    }
                } else if (strcmp((char*)child->name, "TotalPoints") == 0) {
                    xmlChar* points = xmlNodeGetContent(child);
                    team->total_points = atoi((char*)points);
                    xmlFree(points);
                }
            }
        } else if (strcmp((char*)node->name, "Race") == 0) {
            if (race_count >= MAX_RACES) continue;
            struct Race* race = &races[race_count++];

            for (xmlNode* child = node->children; child; child = child->next) {
                if (child->type != XML_ELEMENT_NODE) continue;

                xmlChar* content = xmlNodeGetContent(child);
                if (strcmp((char*)child->name, "Date") == 0) {
                    strncpy(race->date, (char*)content, sizeof(race->date) - 1);
                } else if (strcmp((char*)child->name, "Circuit") == 0) {
                    strncpy(race->circuit, (char*)content, sizeof(race->circuit) - 1);
                } else if (strcmp((char*)child->name, "Country") == 0) {
                    strncpy(race->country, (char*)content, sizeof(race->country) - 1);
                } else if (strcmp((char*)child->name, "Sprint") == 0) {
                    race->sprint = atoi((char*)content);
                } else if (strcmp((char*)child->name, "Completed") == 0) {
                    race->completed = atoi((char*)content);
                } else if (strcmp((char*)child->name, "DriverPoints") == 0) {
                    char* positions = (char*)content;
                    char* token = strtok(positions, ",");
                    int idx = 0;
                    while (token && idx < MAX_TEAMS * MAX_DRIVERS) {
                        race->finishing_positions[idx++] = atoi(token);
                        token = strtok(NULL, ",");
                    }
                } else if (strcmp((char*)child->name, "MapPath") == 0) {
                    strncpy(race->map_path, (char*)content, sizeof(race->map_path) - 1);
                }
                xmlFree(content);
            }
        }
    }

    xmlFreeDoc(doc);
    printf("Successfully opened '%s'\n", filename);
}

void parse_race_points(struct Race* race, const char* positions, char* error) {
    char positions_copy[256];
    strncpy(positions_copy, positions, sizeof(positions_copy) - 1);
    positions_copy[sizeof(positions_copy) - 1] = '\0';

    int idx = 0;
    char* token = strtok(positions_copy, ",");
    while (token && idx < MAX_TEAMS * MAX_DRIVERS) {
        race->finishing_positions[idx++] = atoi(token);
        token = strtok(NULL, ",");
    }

    if (idx != MAX_TEAMS * MAX_DRIVERS) {
        if (error) strcpy(error, "Invalid number of positions");
        return;
    }

    for (int i = 0; i < idx; i++) {
        int pos = race->finishing_positions[i];
        if (pos < 1 || pos > MAX_TEAMS * MAX_DRIVERS) {
            if (error) strcpy(error, "Invalid position value");
            return;
        }
        for (int j = 0; j < idx; j++) {
            if (i != j && race->finishing_positions[i] == race->finishing_positions[j]) {
                if (error) strcpy(error, "Duplicate position value");
                return;
            }
        }
    }
}

void calculate_race_points(struct Race* race) {
    int points_table[] = {25, 18, 15, 12, 10, 8, 6, 4, 2, 1};
    int sprint_points[] = {8, 7, 6, 5, 4, 3, 2, 1};
    int* points = race->sprint ? sprint_points : points_table;
    int max_positions = race->sprint ? 8 : 10;

    memset(race->driver_points, 0, sizeof(race->driver_points));
    memset(race->constructor_points, 0, sizeof(race->constructor_points));

    for (int i = 0; i < MAX_TEAMS * MAX_DRIVERS; i++) {
        int pos = race->finishing_positions[i];
        if (pos >= 1 && pos <= max_positions) {
            race->driver_points[i] = points[pos - 1];
        }
        printf("Driver %d: Position %d, Points %d\n", i, pos, race->driver_points[i]);
    }

    for (int i = 0; i < team_count; i++) {
        for (int j = 0; j < teams[i].driver_count; j++) {
            int driver_idx = i * MAX_DRIVERS + j;
            race->constructor_points[i] += race->driver_points[driver_idx];
        }
        printf("Team %d: Points %d\n", i, race->constructor_points[i]);
    }
}

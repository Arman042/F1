//
//  list.c
//  Formula1
//
//  Created by Arman on 18.03.25.
//

#include <stdio.h>
#include "datastructure.h"
#include "list.h"

void display_calendar(void) {
    printf("\n--- 2025 F1 Calendar ---\n");
    for (int i = 0; i < race_count; i++) {
        printf("Race %d: %s, %s (%s)%s\n", i + 1, races[i].date, races[i].circuit,
               races[i].country, races[i].sprint ? " [Sprint]" : "");
    }
}

//
//  menu.h
//  Formula1
//
//  Created by Arman on 18.03.25.
//

#ifndef MENU_H
#define MENU_H

void display_menu(void);
void update_race_results(void);

#endif

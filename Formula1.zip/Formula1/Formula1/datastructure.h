#ifndef DATASTRUCTURE_H
#define DATASTRUCTURE_H

#define MAX_TEAMS 10
#define MAX_DRIVERS 2
#define MAX_RACES 24

struct Driver {
    char name[50];
    int car_number;
    char nationality[50];
    int total_points;
    char car_model[50];
    char bio[256];
};

struct Team {
    char name[50];
    struct Driver drivers[MAX_DRIVERS];
    int driver_count;
    int total_points;
};

struct Race {
    char date[20];
    char circuit[50];
    char country[50];
    int sprint;
    int completed;
    int finishing_positions[MAX_TEAMS * MAX_DRIVERS];
    int driver_points[MAX_TEAMS * MAX_DRIVERS];
    int constructor_points[MAX_TEAMS];
    char map_path[256];
};

extern struct Team teams[MAX_TEAMS];
extern int team_count;
extern struct Race races[MAX_RACES];
extern int race_count;

void load(const char* filename);
void parse_race_points(struct Race* race, const char* positions, char* error);
void calculate_race_points(struct Race* race);

#endif
